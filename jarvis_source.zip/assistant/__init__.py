"""Assistant engine and prompts."""
